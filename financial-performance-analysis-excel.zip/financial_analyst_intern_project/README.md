# Financial Performance Analysis & Budget Variance Dashboard

A beginner-friendly portfolio project built for entry-level **Financial Analyst, FP&A, Finance Executive, MIS, and Business Analyst** roles.

## Project Objective

Analyze monthly financial performance using Excel and answer practical business questions around:

- Revenue vs. budget
- Operating expense variance
- Net profit and net margin
- Revenue growth
- Business-unit performance
- Simple next-month forecasting
- Management reporting through charts and KPIs

## Tools Used

- Microsoft Excel
- Excel formulas: `SUMIF`, `IFERROR`, `AVERAGE`
- Conditional formatting
- Financial KPI reporting
- Charts and dashboard design
- CSV data handling

## Dataset

The dataset is **synthetic practice data created specifically for this portfolio project**. It contains monthly financial information for four business units across 2024–2025.

Business units:

- Retail
- E-commerce
- B2B
- Services

Main fields include:

`Month`, `Business Unit`, `Revenue`, `Budget Revenue`, `COGS`, `Operating Expenses`, `Budget Opex`, `Cash Inflows`, `Cash Outflows`

## Key Calculations

### Revenue Variance
`Actual Revenue - Budget Revenue`

### Opex Variance
`Budget Opex - Actual Opex`

A positive value indicates that actual operating expenses were below budget.

### Net Profit
`Revenue - COGS - Operating Expenses`

### Net Margin
`Net Profit / Revenue`

### Revenue Growth
`Current Month Revenue / Previous Month Revenue - 1`

### Forecast
A simple three-month average baseline is used to estimate the next month's revenue and expenses. This is a learning exercise, not a production forecasting model.

## Workbook Structure

### `Raw_Data`
Original synthetic financial records with a source column.

### `Monthly_Analysis`
Formula-driven monthly revenue, expenses, variances, profit, margins, growth, and a simple forecast block.

### `Unit_Analysis`
Business-unit revenue, expenses, profit, variance, and margin comparison.

### `Dashboard`
Management-style dashboard with KPI cards, insights, charts, and business-unit comparison.

### `Project_Notes`
Project purpose, dataset notes, tools, and presentation guidance.

## Dashboard Preview

![Dashboard Preview](images/dashboard_preview.png)

## Business Questions Answered

1. Are revenues above or below budget?
2. Are operating expenses controlled against budget?
3. What is the overall net profit and margin?
4. Which business units generate the most revenue?
5. How is revenue changing month over month?
6. What is a simple baseline forecast for the next month?

## Resume Description

**Financial Performance Analysis & Budget Variance Dashboard | Excel**

- Analyzed monthly revenue, expenses, profit, and budget data using Microsoft Excel.
- Compared actual financial performance with budgeted figures and calculated revenue and operating expense variances.
- Prepared management summaries using Excel formulas, conditional formatting, and charts.
- Performed trend analysis and business-unit comparison to identify changes in financial performance.
- Built a dashboard presenting revenue, profit, margin, variance, and forecast KPIs.

## Interview Explanation

> I created an Excel-based financial performance dashboard using synthetic business data. I organized monthly revenue, budget, COGS, and operating expense data, then calculated revenue variance, expense variance, net profit, net margin, and monthly growth. I also compared business units and created a simple three-month average forecast. The final dashboard was designed to communicate financial performance clearly to management.

## GitHub Note

This is a **Personal Portfolio Project**. It is not company experience and does not represent real client or employer data.
