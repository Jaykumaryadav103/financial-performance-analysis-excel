"""Simple Python companion script for the portfolio project.

Reads the synthetic CSV dataset and prints a few high-level financial metrics.
No external packages are required.
"""

import csv
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CSV_PATH = ROOT / "data" / "financial_data.csv"


def load_rows(path: Path):
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def to_num(value: str) -> float:
    return float(value)


def main() -> None:
    rows = load_rows(CSV_PATH)

    total_revenue = sum(to_num(r["Revenue_INR"]) for r in rows)
    total_budget = sum(to_num(r["Budget_Revenue_INR"]) for r in rows)
    total_cogs = sum(to_num(r["COGS_INR"]) for r in rows)
    total_opex = sum(to_num(r["Operating_Expenses_INR"]) for r in rows)
    total_profit = total_revenue - total_cogs - total_opex
    net_margin = total_profit / total_revenue if total_revenue else 0

    by_unit = defaultdict(float)
    for r in rows:
        by_unit[r["Business_Unit"]] += to_num(r["Revenue_INR"])

    print("Financial Performance Analysis")
    print("=" * 32)
    print(f"Total Revenue : INR {total_revenue:,.0f}")
    print(f"Budget Revenue: INR {total_budget:,.0f}")
    print(f"Total Profit  : INR {total_profit:,.0f}")
    print(f"Net Margin    : {net_margin:.1%}")
    print("\nRevenue by Business Unit:")
    for unit, revenue in sorted(by_unit.items(), key=lambda x: x[1], reverse=True):
        print(f"- {unit}: INR {revenue:,.0f}")


if __name__ == "__main__":
    main()
